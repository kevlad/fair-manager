// Placeholder for a custom global validation pipe.
// Currently configured globally in main.ts via Nest ValidationPipe.
